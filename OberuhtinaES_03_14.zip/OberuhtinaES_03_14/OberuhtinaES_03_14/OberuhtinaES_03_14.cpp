﻿// OberuhtinaES_03_14.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <algorithm>
#include <Windows.h>
using namespace std;
class School
{
public:
	int number;
	int counStudent;
	bool akredit;
	string status;


	School(int number,int counStudent, bool akredit, const string& status)
		: number(number), counStudent(counStudent), akredit(akredit), status(status)
	{
	}

private:


};

School AddSchool() {
	int number;
	int counStudent;
	bool akredit;
	string status;

	cout << "Введите номер школы\n";
	cin >> number;

	cout << "Введите колколичество учащихся\n";
	cin >> counStudent;

	cout << "Введите наличие аккредитация(0 или 1)\n";
	int cheakBool;
	cin >> cheakBool;
	if (cheakBool == 0) akredit = false;
	else akredit = true;
	cout << "Введите статус\n";
	cin >> status;
	School school = School(number, counStudent, akredit, status);
	return school;
}
void WriteFile(vector<School> vector) {
	ofstream file("text.txt");
	if (file.is_open())
	{
		for (int i = 0; i < vector.size(); i++) {
			file << "\n";
			file << "Номер школы:" << vector[i].number << "\n";
			file << "Количество учащихся:" << vector[i].counStudent << "\n";
			file << "Аккредитация :" << vector[i].akredit << "\n";
			file << "Статус:" << vector[i].status << "\n";
		}
		file.close();
	}
}

void ReadFile() {
	ifstream file("text.txt");
	if (file.is_open()) {
		string line;
		while (getline(file, line)) {
			cout << line << "\n";
		}
		file.close();
	}
}
vector<School> SortMax(vector<School> schools) {
	sort(schools.begin(), schools.end(), [](const School& a, const School& b) {
		return a.number > b.number;
		});
	return schools;
}

vector<School> SortMin(vector<School> schools) {
	sort(schools.begin(), schools.end(), [](const School& a, const School& b) {
		return a.number < b.number;
		});
	return schools;
}


int main()
{
	setlocale(LC_ALL, "RU");
	SetConsoleCP(1251);
	vector<School> schools;
	string action;

	while (true) {
		cout << "1. Добавить школу\n2. Сортировка по убыванию\n3. Сортировка по возрастанию\n4. Вывод школ\n0. Выход\n";
		cin >> action;

		if (action == "1") {
			schools.push_back(AddSchool());
			WriteFile(schools);
		}
		else if (action == "2") {
			schools = SortMax(schools);
			WriteFile(schools);
			ReadFile();
		}
		else if (action == "3") {
			schools = SortMin(schools);
			WriteFile(schools);
			ReadFile();
		}
		else if (action == "4") {
			ReadFile();
		}
		else if (action == "0") {
			break;
		}
		else {
			cout << "Неверный ввод. Попробуйте снова.\n";
		}
	}

	return 0;
}
// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
